function Y = SampleFittnes2(Chrmosom,Params)
Y=sum(Chrmosom.^2.*Params);