function Y = SampleFittnes(Chrmosom)
Y=sum(Chrmosom.^2);